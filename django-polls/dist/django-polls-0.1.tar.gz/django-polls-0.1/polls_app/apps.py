from django.apps import AppConfig


class PollsAppConfig(AppConfig):
    name = 'polls_app'
